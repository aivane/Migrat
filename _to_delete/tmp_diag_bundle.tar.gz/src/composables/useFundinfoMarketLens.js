import { computed, reactive } from 'vue'
import { fundsByType } from '../data/fundinfoData'
import { performanceSeries, CMP_LABELS } from './useFundinfoThemeTrend'

// ==========================================================================
// Section ① Market Lens — แนวโน้มสินทรัพย์ (Mixed Fund)
// Ported from computeScopes() (else branch), trendStats(), trendLeaders(),
// trendBenchmark(), renderTrend() and buildTrendChart() in the fundinfo
// v3.2.1 HTML prototype. Groups mixed funds by each asset class that makes
// up >= 10% of the fund's mix (a fund can belong to more than one scope),
// then shows up to 5 lines on one chart — 3 leading + 2 lagging by perf,
// or a single line when the person drills into one scope.
// ==========================================================================

const MAX_LINES = 5
const BENCH = { name: 'พอร์ตผสม 60/40', ret: 5.4 }

function seedFromId(id) {
  return [...String(id)].reduce((sum, ch) => sum + ch.charCodeAt(0), 71)
}

export function trendSeries(scope) {
  return performanceSeries(seedFromId(scope.id), scope.perf, CMP_LABELS.length)
}

// จัดกลุ่มกองทุนผสมตามสินทรัพย์ที่มีน้ำหนัก >= 10% ในพอร์ต (กองเดียวอยู่ได้หลายหมวด)
function computeScopes(funds) {
  const groups = {}
  funds.forEach((fund) => {
    ;(fund.mix || fund.asset || []).forEach((item) => {
      if (item.percent < 10) return
      ;(groups[item.name] = groups[item.name] || []).push(fund)
    })
  })
  return Object.entries(groups).map(([key, list], idx) => {
    const members = [...new Map(list.map((f) => [f.id, f])).values()]
    return {
      id: key,
      title: key,
      idx,
      members,
      perf: +(members.reduce((sum, f) => sum + f.perf, 0) / members.length).toFixed(1),
      flow: members.reduce((sum, f) => sum + f.netbuy, 0),
    }
  })
}

function trendStats(scope) {
  const data = trendSeries(scope)
  return {
    scope,
    data,
    momentum: +(data.at(-1) - data.at(-4)).toFixed(1),
  }
}

export function useFundinfoMarketLens(type = 'mixed') {
  const funds = fundsByType(type)
  const scopes = computeScopes(funds)
  const stats = scopes.map(trendStats)

  const state = reactive({
    scope: null, // scope id ที่เจาะดูอยู่ (null = ภาพรวมตลาด)
  })

  const leader = computed(() => [...stats].sort((a, b) => b.scope.perf - a.scope.perf)[0])
  const laggard = computed(() => [...stats].sort((a, b) => a.scope.perf - b.scope.perf)[0])
  const momentumTop = computed(() => [...stats].sort((a, b) => b.momentum - a.momentum)[0])
  const positiveCount = computed(() => scopes.filter((s) => s.perf > 0).length)

  const activeStat = computed(() => stats.find((s) => s.scope.id === state.scope) || null)

  // เส้นที่แสดงบนกราฟ: เจาะดูหมวดเดียวถ้าเลือกไว้ ไม่งั้นแสดง 3 กลุ่มนำ + 2 กลุ่มตาม (ไม่เกิน 5 เส้น)
  const chartLines = computed(() => {
    if (activeStat.value) return [activeStat.value]
    const ranked = [...stats].sort((a, b) => b.scope.perf - a.scope.perf)
    const picked = [...ranked.slice(0, 3), ...ranked.slice(-2)]
    const seen = new Set()
    return picked
      .filter((s) => {
        if (seen.has(s.scope.id)) return false
        seen.add(s.scope.id)
        return true
      })
      .slice(0, MAX_LINES)
  })

  const chartTitle = computed(() =>
    state.scope ? `แนวโน้ม ${state.scope}` : 'ภาพตลาด: 3 กลุ่มนำและ 2 กลุ่มตาม',
  )

  function setScope(id) {
    state.scope = state.scope === id ? null : id
  }

  function clearScope() {
    state.scope = null
  }

  return {
    scopes,
    stats,
    state,
    leader,
    laggard,
    momentumTop,
    positiveCount,
    chartLines,
    chartTitle,
    bench: BENCH,
    setScope,
    clearScope,
  }
}